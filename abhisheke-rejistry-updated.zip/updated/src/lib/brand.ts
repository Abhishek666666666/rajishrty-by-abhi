import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface Brand {
  brand_name: string;
  tagline: string;
  watermark: string;
  address: string;
  support_phone: string;
  office_name: string;
  reward_amount: number;
  required_stamps: number;
}

const DEFAULT_BRAND: Brand = {
  brand_name: "अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय",
  tagline: "हर रजिस्ट्री पर स्टांप, 5 स्टांप पर ₹2,000 इनाम",
  watermark: "Made by Abhishek Sharma from Agar",
  address: "आगर मालवा, मध्य प्रदेश",
  support_phone: "",
  office_name: "E-Registry",
  reward_amount: 2000,
  required_stamps: 5,
};

let cache: Brand | null = null;
let inflight: Promise<Brand> | null = null;

async function fetchBrand(): Promise<Brand> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    const { data } = await supabase
      .from("owner_settings")
      .select("brand_name,tagline,watermark,address,support_phone,office_name,reward_amount,required_stamps")
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    cache = { ...DEFAULT_BRAND, ...(data ?? {}) };
    return cache;
  })();
  const res = await inflight;
  inflight = null;
  return res;
}

export function invalidateBrand() {
  cache = null;
}

export function useBrand(): Brand {
  const [b, setB] = useState<Brand>(cache ?? DEFAULT_BRAND);
  useEffect(() => {
    let alive = true;
    const refresh = () => {
      fetchBrand()
        .then((v) => { if (alive) setB(v); })
        .catch(() => { if (alive) setB(DEFAULT_BRAND); });
    };

    refresh();
    window.addEventListener("brand-settings-updated", refresh);
    return () => {
      alive = false;
      window.removeEventListener("brand-settings-updated", refresh);
    };
  }, []);
  return b;
}
