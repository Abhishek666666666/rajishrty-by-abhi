import { supabase } from "@/integrations/supabase/client";

export async function applyStampByToken(token: string) {
  // Token may be a URL (from camera scan) — extract the trailing token
  const match = token.match(/ERQR-[A-Z0-9-]+/);
  const t = match ? match[0] : token.trim();
  const { data, error } = await supabase.rpc("apply_stamp_by_token", { p_token: t });
  if (error) throw error;
  return data as { ok: boolean; error?: string; customer?: any; reward_ready?: boolean };
}
