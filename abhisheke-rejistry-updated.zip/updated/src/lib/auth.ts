import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    let fallback: ReturnType<typeof setTimeout> | null = null;

    const apply = (nextSession: Session | null) => {
      if (!alive) return;
      if (fallback) {
        clearTimeout(fallback);
        fallback = null;
      }
      setSession(nextSession);
      setUser(nextSession?.user ?? null);
      setLoading(false);
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => {
      apply(s ?? null);
    });

    supabase.auth.getSession().then(({ data }) => apply(data.session ?? null)).catch(() => apply(null));
    fallback = setTimeout(() => apply(null), 4000);

    return () => {
      alive = false;
      if (fallback) clearTimeout(fallback);
      subscription.unsubscribe();
    };
  }, []);

  return { user, session, loading };
}
