import { supabase } from "@/integrations/supabase/client";

const TOKEN_TTL_MS = 5 * 60 * 1000;
const PUBLIC_APP_URL = "https://abhisheke-rejistry.lovable.app";

function rand(n: number) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < n; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

export async function createToken(customer: { id: string; customer_code: string; owner_id: string }) {
  const safeCode = customer.customer_code.replace(/[^A-Z0-9]/gi, "") || "CODE";
  const token = `ERQR-${safeCode}-${rand(6)}`;
  const expires_at = new Date(Date.now() + TOKEN_TTL_MS).toISOString();
  const { error } = await supabase.from("qr_tokens").insert({
    token,
    customer_id: customer.id,
    owner_id: customer.owner_id,
    expires_at,
  });
  if (error) throw error;
  return { token, expiresAt: Date.now() + TOKEN_TTL_MS };
}

export function scanUrl(token: string) {
  if (typeof window === "undefined") return `/scan/${token}`;
  const origin = window.location.origin;
  const isPrivatePreview =
    origin.includes("lovableproject.com") ||
    origin.includes("id-preview--") ||
    origin.includes("-dev.lovable.app");
  const publicOrigin = isPrivatePreview ? PUBLIC_APP_URL : origin;
  return `${publicOrigin}/scan/${encodeURIComponent(token)}`;
}
