interface Props {
  filled: number;
  total?: number;
  size?: "sm" | "md" | "lg";
  animateLast?: boolean;
}

export function StampCircles({ filled, total = 5, size = "md", animateLast = false }: Props) {
  const dim = size === "sm" ? "h-4 w-4" : size === "lg" ? "h-12 w-12" : "h-9 w-9";
  const inner = size === "lg" ? "text-lg" : "text-xs";
  const gap = size === "sm" ? "gap-1.5" : "gap-2.5";
  const f = Math.min(filled, total);
  return (
    <div className={`flex ${gap} justify-center`}>
      {Array.from({ length: total }).map((_, i) => {
        const isFilled = i < f;
        const isLatest = animateLast && i === f - 1;
        return (
          <div
            key={i}
            className={[
              dim,
              "rounded-full flex items-center justify-center transition-all",
              isFilled
                ? "bg-gradient-gold text-white shadow-gold"
                : "border-2 border-white/20 bg-white/5",
              isLatest ? "animate-stamp" : "",
            ].join(" ")}
          >
            {isFilled && size !== "sm" && <span className={`${inner} font-bold`}>✓</span>}
          </div>
        );
      })}
    </div>
  );
}
