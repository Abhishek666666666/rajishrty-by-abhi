import { Link, useNavigate } from "@tanstack/react-router";
import { ReactNode, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { BrandHeader } from "@/components/BrandHeader";
import { BrandFooter } from "@/components/BrandFooter";

export function OwnerShell({
  children, title, subtitle, back, right,
}: { children: ReactNode; title: string; subtitle?: string; back?: string; right?: ReactNode }) {
  const { user, loading } = useAuth();
  const nav = useNavigate();

  useEffect(() => {
    if (!loading && !user) nav({ to: "/owner/login" });
  }, [user, loading, nav]);

  if (loading || !user) {
    return (
      <main className="flex min-h-screen flex-col bg-background">
        <BrandHeader back="/" />
        <div className="flex flex-1 items-center justify-center px-5">
          <div className="text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-accent border-t-transparent" />
            <p className="mt-4 text-sm text-text-light">लॉगिन चेक हो रहा है...</p>
          </div>
        </div>
        <BrandFooter />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background animate-page-in">
      <header className="sticky top-0 z-20 bg-primary text-white shadow-lg">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-5 py-3.5">
          <div className="flex items-center gap-3">
            {back ? (
              <Link to={back as any} className="text-white/70 hover:text-white">←</Link>
            ) : (
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-base">📋</span>
            )}
            <div>
              <p className="font-display text-base leading-tight">{title}</p>
              {subtitle && <p className="text-[11px] uppercase tracking-wider text-white/50">{subtitle}</p>}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {right}
            <button
              onClick={async () => { await supabase.auth.signOut(); nav({ to: "/" }); }}
              className="rounded-full bg-white/10 px-3 py-1.5 text-xs hover:bg-white/20"
            >
              Logout
            </button>
          </div>
        </div>
      </header>
      <div className="mx-auto w-full max-w-2xl px-5 py-6">{children}</div>
    </main>
  );
}
