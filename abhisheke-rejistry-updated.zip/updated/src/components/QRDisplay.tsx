import { QRCodeSVG } from "qrcode.react";
import { useEffect, useState } from "react";

export function QRDisplay({
  token,
  url,
  expiresAt,
  onExpire,
}: {
  token: string;
  url: string;
  expiresAt: number;
  onExpire?: () => void;
}) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, []);
  const left = Math.max(0, Math.floor((expiresAt - now) / 1000));
  const expired = left === 0;
  const danger = left > 0 && left < 60;
  const m = Math.floor(left / 60);
  const s = (left % 60).toString().padStart(2, "0");

  useEffect(() => {
    if (expired && onExpire) onExpire();
  }, [expired, onExpire]);

  return (
    <div className="rounded-2xl bg-white p-5 shadow-card">
      <p className="text-center text-xs uppercase tracking-widest text-text-light">
        ग्राहक के फ़ोन से स्कैन करें
      </p>
      <p className="mt-1 text-center text-[11px] text-text-light">
        📷 Google Lens / Camera से स्कैन → वेब खुलेगी → स्टांप अपने आप लगेगा
      </p>
      <div className="mt-3 flex justify-center">
        <span className="rounded-full bg-accent-pale px-3 py-1 font-mono text-xs font-semibold text-accent">
          {token}
        </span>
      </div>
      <div className={`mt-4 mx-auto w-fit rounded-xl border-2 p-3 transition-all ${danger ? "border-destructive animate-pulse-red" : "border-accent/30"} ${expired ? "blur-sm" : ""}`}>
        <QRCodeSVG value={url} size={196} bgColor="#ffffff" fgColor="#0a0f1e" level="M" />
      </div>
      <div className="mt-4 text-center">
        {expired ? (
          <p className="text-sm font-semibold text-destructive">समय समाप्त — रिफ़्रेश करें</p>
        ) : (
          <p className="text-sm font-semibold text-text-mid">
            <span className={danger ? "text-destructive" : ""}>{m}:{s}</span> में समाप्त
          </p>
        )}
      </div>
      <p className="mt-2 text-center text-[11px] text-text-light">
        हर QR एक ही बार उपयोग होता है · 5 मिनट में समाप्त
      </p>
    </div>
  );
}
