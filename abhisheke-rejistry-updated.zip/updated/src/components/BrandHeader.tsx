import { Link } from "@tanstack/react-router";
import { useBrand } from "@/lib/brand";

export function BrandHeader({ back, dark = false }: { back?: string; dark?: boolean }) {
  const b = useBrand();
  return (
    <header className={`sticky top-0 z-20 ${dark ? "bg-primary text-white" : "bg-primary text-white"} shadow-lg`}>
      <div className="mx-auto flex max-w-2xl items-center gap-3 px-4 py-3">
        {back && (
          <Link to={back as any} className="text-white/70 hover:text-white text-lg leading-none">←</Link>
        )}
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-gold text-lg shadow-gold">
          📋
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="font-display text-[15px] leading-tight font-semibold truncate">{b.brand_name}</h1>
          {b.address && <p className="text-[10px] uppercase tracking-wider text-white/55 truncate">{b.address}</p>}
        </div>
      </div>
    </header>
  );
}
