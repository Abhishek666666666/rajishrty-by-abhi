import { StampCircles } from "./StampCircles";

interface Customer {
  name: string;
  customer_code: string;
  stamps: number;
}

export function LoyaltyCard({ customer, required = 5, rewardAmount = 2000, animate = false }: {
  customer: Customer;
  required?: number;
  rewardAmount?: number;
  animate?: boolean;
}) {
  const inCycle = customer.stamps % required;
  const cycleStamps = customer.stamps > 0 && inCycle === 0 ? required : inCycle;
  const remaining = required - cycleStamps;
  const ready = customer.stamps > 0 && inCycle === 0;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-navy p-6 text-white shadow-card">
      <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-accent/20 blur-3xl" />
      <div className="relative">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-widest text-white/50">ग्राहक</p>
            <h3 className="font-display text-2xl font-semibold leading-tight">{customer.name}</h3>
            <p className="mt-0.5 font-mono text-xs text-accent-light">{customer.customer_code}</p>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-xl">📋</div>
        </div>

        <div className="mt-7">
          <StampCircles filled={cycleStamps} total={required} size="lg" animateLast={animate} />
        </div>

        <p className="mt-5 text-center text-sm text-white/80">
          {ready
            ? "🎉 इनाम तैयार है! ओनर से क्लेम करें"
            : `${remaining} और रजिस्ट्री कराएँ — ₹${rewardAmount.toLocaleString("en-IN")} मिलेगा!`}
        </p>

        <div className="mt-5 flex items-center justify-between rounded-xl bg-white/8 px-4 py-3 ring-1 ring-white/10">
          <div className="flex items-center gap-2">
            <span className="text-lg">🎁</span>
            <span className="text-xs text-white/70">{required} रजिस्ट्री पूरी पर</span>
          </div>
          <span className="font-display text-xl font-bold text-accent-light">₹{rewardAmount.toLocaleString("en-IN")}</span>
        </div>
      </div>
    </div>
  );
}
