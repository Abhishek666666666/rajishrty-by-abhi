import { useBrand } from "@/lib/brand";

export function BrandFooter({ dark = false }: { dark?: boolean }) {
  const b = useBrand();
  return (
    <footer className={`mt-10 border-t ${dark ? "border-white/10 text-white/50" : "border-border text-text-light"} px-5 py-5 text-center`}>
      <p className="font-display text-[11px] tracking-wider uppercase">{b.brand_name}</p>
      {b.support_phone && (
        <p className="mt-1 text-[11px]">
          📞 <a href={`tel:${b.support_phone}`} className="hover:underline">{b.support_phone}</a>
        </p>
      )}
      <p className="mt-2 text-[10px] italic opacity-70">✦ {b.watermark} ✦</p>
    </footer>
  );
}
