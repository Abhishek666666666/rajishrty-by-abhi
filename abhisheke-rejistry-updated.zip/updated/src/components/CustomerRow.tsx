import { Link } from "@tanstack/react-router";
import { StampCircles } from "./StampCircles";

interface Customer { id: string; name: string; customer_code: string; mobile: string; stamps: number }

export function CustomerRow({ c, required = 5, rewardAmount = 2000 }: { c: Customer; required?: number; rewardAmount?: number }) {
  const ready = c.stamps > 0 && c.stamps % required === 0;
  const cycle = ready ? required : c.stamps % required;
  const initials = c.name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  return (
    <Link
      to="/owner/customers/$id"
      params={{ id: c.id }}
      className="flex items-center gap-3 rounded-2xl bg-card p-4 shadow-card transition-transform hover:-translate-y-0.5"
    >
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl font-display text-base font-bold text-white ${ready ? "bg-gradient-gold shadow-gold" : "bg-primary"}`}>
        {initials}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate font-medium">{c.name}</p>
          {ready && <span className="rounded-full bg-accent-pale px-2 py-0.5 text-[10px] font-semibold text-accent">🎁 ₹{rewardAmount}</span>}
        </div>
        <p className="font-mono text-xs text-text-light">{c.customer_code} · {c.mobile}</p>
        <div className="mt-2"><StampCircles filled={cycle} total={required} size="sm" /></div>
      </div>
      <span className="text-text-light">›</span>
    </Link>
  );
}
