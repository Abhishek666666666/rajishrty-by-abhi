import { useEffect, useRef, useState } from "react";

export function QRScanner({ onResult }: { onResult: (text: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const scannerRef = useRef<any>(null);
  const [active, setActive] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(() => {});
        scannerRef.current.clear?.();
      }
    };
  }, []);

  async function start() {
    setError("");
    try {
      const { Html5Qrcode } = await import("html5-qrcode");
      const id = "qr-reader-region";
      if (ref.current) ref.current.id = id;
      const scanner = new Html5Qrcode(id);
      scannerRef.current = scanner;
      await scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 240, height: 240 } },
        (text) => {
          onResult(text);
          scanner.stop().then(() => setActive(false)).catch(() => {});
        },
        () => {},
      );
      setActive(true);
    } catch (e: any) {
      setError(e?.message ?? "Camera nahi mila");
    }
  }

  async function stop() {
    if (scannerRef.current) {
      await scannerRef.current.stop().catch(() => {});
      setActive(false);
    }
  }

  return (
    <div>
      <div ref={ref} className="overflow-hidden rounded-xl bg-black/5" style={{ minHeight: active ? 240 : 0 }} />
      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
      <div className="mt-4 flex gap-2">
        {!active ? (
          <button onClick={start} className="flex-1 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground">
            📷 Camera On Karo
          </button>
        ) : (
          <button onClick={stop} className="flex-1 rounded-xl bg-destructive py-3 text-sm font-semibold text-white">
            Stop Scanner
          </button>
        )}
      </div>
    </div>
  );
}
