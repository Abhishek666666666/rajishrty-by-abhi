import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { BrandHeader } from "@/components/BrandHeader";
import { BrandFooter } from "@/components/BrandFooter";

export const Route = createFileRoute("/customer")({ component: CustomerLogin });

function CustomerLogin() {
  const nav = useNavigate();
  const [code, setCode] = useState("");
  const [mobile, setMobile] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const cleanCode = code.trim().toUpperCase();
    const cleanMobile = mobile.trim();

    let query = supabase.from("customers").select("customer_code, mobile, name");
    if (cleanCode) query = query.ilike("customer_code", cleanCode);
    if (cleanMobile) query = query.eq("mobile", cleanMobile);
    const { data, error } = await query.limit(1).maybeSingle();
    setBusy(false);
    if (error || !data) {
      toast.error("❌ कोड या मोबाइल नंबर मेल नहीं खाता — ओनर से चेक करें");
      return;
    }
    nav({ to: "/card/$code", params: { code: data.customer_code } });
  }

  return (
    <main className="min-h-screen bg-background animate-page-in flex flex-col">
      <BrandHeader back="/" />
      <div className="mx-auto w-full max-w-md flex-1 px-5 py-8">
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-2xl text-white">🙋</div>
          <h2 className="mt-3 font-display text-2xl">ग्राहक लॉगिन</h2>
          <p className="mt-1 text-sm text-text-light">अपना कार्ड देखने के लिए विवरण भरें</p>
        </div>
        <form onSubmit={submit} className="mt-6 rounded-2xl bg-card p-6 shadow-card">
          <label className="text-xs font-semibold uppercase tracking-wider text-text-light">ग्राहक कोड</label>
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="REG-0001"
            required
            className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 font-mono text-lg uppercase tracking-wider focus:border-accent focus:outline-none"
          />
          <label className="mt-5 block text-xs font-semibold uppercase tracking-wider text-text-light">मोबाइल नंबर</label>
          <input
            value={mobile}
            onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
            placeholder="9876543210"
            inputMode="numeric"
            required
            className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-lg focus:border-accent focus:outline-none"
          />
          <button
            disabled={busy}
            className="mt-6 w-full rounded-xl bg-gradient-gold py-4 font-semibold text-white shadow-gold transition-transform active:scale-[0.98] disabled:opacity-60"
          >
            {busy ? "ढूंढ रहे हैं..." : "📲 कार्ड देखें"}
          </button>
        </form>

        {/* Fix 3: How to get code section */}
        <div className="mt-5 rounded-2xl border border-accent/20 bg-accent-pale/30 p-5">
          <p className="text-xs font-semibold uppercase tracking-wider text-accent mb-3">🤔 कोड कैसे मिलेगा?</p>
          <ol className="space-y-2 text-sm text-text-mid">
            <li className="flex items-start gap-2">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-white text-[10px] font-bold">1</span>
              <span>पहली बार आने पर ओनर से <strong>अपना नाम</strong> बताएं</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-white text-[10px] font-bold">2</span>
              <span>वो आपको एक <strong>4-digit कोड</strong> देंगे</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-white text-[10px] font-bold">3</span>
              <span>उस <strong>कोड और अपने मोबाइल नंबर</strong> से लॉगिन करें</span>
            </li>
          </ol>
        </div>
      </div>
      <BrandFooter />
    </main>
  );
}
