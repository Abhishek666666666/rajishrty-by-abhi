import { createFileRoute, Link } from "@tanstack/react-router";
import { useBrand } from "@/lib/brand";
import { BrandFooter } from "@/components/BrandFooter";

export const Route = createFileRoute("/")({ component: Home });

const WHATSAPP_NUMBER = "919926653319";
const PHONE = "9926653319";

function Home() {
  const b = useBrand();
  return (
    <main className="relative min-h-screen overflow-hidden bg-primary text-white flex flex-col">
      {/* Fix 2: Hide Lovable badge */}
      <style>{`[data-lovable-badge], #lovable-badge, .lovable-badge, iframe[src*="lovable"] { display: none !important; }`}</style>

      <div className="pointer-events-none absolute -left-32 top-10 h-[420px] w-[420px] rounded-full bg-accent/20 blur-[120px]" />
      <div className="pointer-events-none absolute -right-32 bottom-0 h-[420px] w-[420px] rounded-full bg-accent-light/15 blur-[120px]" />

      <header className="relative z-10 mx-auto flex w-full max-w-5xl items-center justify-between px-6 pt-5">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-gold text-lg shadow-gold">📋</div>
          <span className="hidden sm:inline font-display text-sm font-semibold tracking-wide text-white/90">{b.office_name}</span>
        </div>
        {PHONE && (
          <a href={`tel:${PHONE}`} className="text-xs text-white/70 hover:text-white">
            📞 {PHONE}
          </a>
        )}
      </header>

      <section className="relative z-10 mx-auto flex w-full max-w-md flex-1 flex-col items-center px-6 pt-10 pb-6 animate-page-in">
        <div className="flex flex-col items-center text-center">
          <h1 className="font-display text-[28px] font-bold leading-snug">
            {b.brand_name}
          </h1>
          {b.address && (
            <p className="mt-2 text-[11px] uppercase tracking-[0.2em] text-white/55">{b.address}</p>
          )}
          <p className="mt-5 text-base leading-relaxed text-white/80">{b.tagline}</p>

          <span className="mt-5 inline-flex items-center gap-2 rounded-full bg-accent-pale/15 px-4 py-1.5 text-sm font-medium text-accent-light ring-1 ring-accent/30">
            🎁 ₹{b.reward_amount.toLocaleString("en-IN")} नकद इनाम
          </span>
        </div>

        <Link
          to="/customer"
          className="mt-10 flex w-full items-center justify-center rounded-2xl bg-gradient-gold px-6 py-4 text-base font-semibold text-white shadow-gold transition-transform active:scale-[0.98]"
        >
          📲 अपना लॉयल्टी कार्ड देखें
        </Link>
        <p className="mt-3 text-center text-xs text-white/55">
          सिर्फ अपना ग्राहक कोड और मोबाइल नंबर डालें
        </p>

        {/* Feature 4: How it Works */}
        <div className="mt-12 w-full">
          <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-white/50 mb-5">यह कैसे काम करता है?</p>
          <div className="flex flex-col gap-3">
            <HowStep num={1} icon="📄" title="रजिस्ट्री करवाएं" desc="अभिषेक कार्यालय में आकर अपनी रजिस्ट्री करवाएं" />
            <HowStep num={2} icon="🏷️" title="डिजिटल स्टांप पाएं" desc="हर रजिस्ट्री पर आपके कार्ड में एक स्टांप जुड़ता है" />
            <HowStep num={3} icon="🎁" title="5 स्टांप पर ₹2,000 नकद जीतें" desc="5 रजिस्ट्री पूरी होने पर तुरंत ₹2,000 इनाम पाएं!" accent />
          </div>
        </div>

        <div className="mt-10 grid w-full grid-cols-3 gap-2 text-center">
          <Feature icon="📲" t="कोई ऐप नहीं" s="सीधे ब्राउज़र में" />
          <Feature icon="⚡" t="तुरंत स्टांप" s="QR स्कैन करें" />
          <Feature icon="🎁" t="कैश इनाम" s={`हर ${b.required_stamps} पर`} />
        </div>

        {/* Feature 5: Contact/Info Section */}
        <div className="mt-10 w-full rounded-2xl border border-white/10 bg-white/5 p-5">
          <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-white/50 mb-4">संपर्क करें</p>
          <div className="space-y-3">
            <ContactItem icon="📞" label="फोन" value={PHONE} href={`tel:${PHONE}`} />
            <ContactItem icon="📍" label="पता" value="आगर मालवा, मध्य प्रदेश" />
            <ContactItem icon="🕐" label="समय" value="सोमवार–शनिवार, सुबह 10 बजे से शाम 6 बजे तक" />
          </div>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] py-3 font-semibold text-white text-sm transition-transform active:scale-[0.98]"
          >
            <span className="text-lg">💬</span> WhatsApp पर संपर्क करें
          </a>
        </div>
      </section>

      <footer className="relative z-10 mx-auto w-full max-w-5xl px-6 pb-5">
        <div className="flex items-center justify-between border-t border-white/10 pt-4 text-[11px] text-white/45">
          <span>© {new Date().getFullYear()} {b.office_name}</span>
          <Link to="/owner/login" className="hover:text-white/80 transition-colors">
            एडमिन लॉगिन →
          </Link>
        </div>
        <div className="mt-2">
          <BrandFooter dark />
        </div>
      </footer>

      {/* Feature 5: Floating WhatsApp Button */}
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-2xl shadow-lg transition-transform hover:scale-110 active:scale-95"
        title="WhatsApp पर संपर्क करें"
      >
        💬
      </a>
    </main>
  );
}

function HowStep({ num, icon, title, desc, accent }: { num: number; icon: string; title: string; desc: string; accent?: boolean }) {
  return (
    <div className={`flex items-start gap-4 rounded-xl p-4 ${accent ? "bg-accent/20 ring-1 ring-accent/30" : "bg-white/5 ring-1 ring-white/10"}`}>
      <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-lg ${accent ? "bg-gradient-gold shadow-gold" : "bg-white/10"}`}>
        {icon}
      </div>
      <div>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-bold uppercase tracking-wider ${accent ? "text-accent-light" : "text-white/40"}`}>चरण {num}</span>
        </div>
        <p className={`font-semibold text-sm mt-0.5 ${accent ? "text-accent-light" : "text-white/90"}`}>{title}</p>
        <p className="text-xs text-white/55 mt-0.5 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

function ContactItem({ icon, label, value, href }: { icon: string; label: string; value: string; href?: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-base mt-0.5">{icon}</span>
      <div>
        <p className="text-[10px] uppercase tracking-wider text-white/40">{label}</p>
        {href ? (
          <a href={href} className="text-sm text-white/80 hover:text-white">{value}</a>
        ) : (
          <p className="text-sm text-white/80">{value}</p>
        )}
      </div>
    </div>
  );
}

function Feature({ icon, t, s }: { icon: string; t: string; s: string }) {
  return (
    <div className="rounded-xl bg-white/5 p-3 ring-1 ring-white/10">
      <div className="text-xl">{icon}</div>
      <p className="mt-1 text-[11px] font-semibold text-white/90">{t}</p>
      <p className="text-[10px] text-white/55">{s}</p>
    </div>
  );
}
