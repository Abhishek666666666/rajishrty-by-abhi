import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { BrandHeader } from "@/components/BrandHeader";
import { BrandFooter } from "@/components/BrandFooter";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/owner/login")({ component: OwnerLogin });

const OWNER_EMAIL = "owner@eregistry.local";
const OWNER_USERNAME = "abhishek";

function OwnerLogin() {
  const nav = useNavigate();
  const { user, loading } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) nav({ to: "/owner/dashboard", replace: true });
  }, [loading, user, nav]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    const cleanUsername = username.trim().toLowerCase();
    const cleanPassword = password.trim();
    if (!cleanUsername || !cleanPassword) return;

    if (cleanUsername !== OWNER_USERNAME) {
      toast.error("गलत यूज़रनेम");
      return;
    }

    setBusy(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: OWNER_EMAIL,
      password: cleanPassword,
    });

    setBusy(false);
    if (error || !data.session) {
      toast.error("गलत यूज़रनेम या पासवर्ड");
      return;
    }
    toast.success("लॉगिन हो गया");
    nav({ to: "/owner/dashboard", replace: true });
  }

  if (loading || user) {
    return (
      <main className="flex min-h-screen flex-col bg-background">
        <BrandHeader back="/" />
        <div className="flex flex-1 items-center justify-center px-5">
          <div className="text-center">
            <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-accent border-t-transparent" />
            <p className="mt-4 text-sm text-text-light">लॉगिन चेक हो रहा है...</p>
          </div>
        </div>
        <BrandFooter />
      </main>
    );
  }

  return (
    <main className="flex min-h-screen flex-col bg-background animate-page-in">
      <BrandHeader back="/" />
      <div className="mx-auto w-full max-w-md flex-1 px-5 py-10">
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-2xl text-white">🔐</div>
          <h1 className="mt-4 font-display text-3xl">ओनर लॉगिन</h1>
          <p className="mt-1 text-sm text-text-light">लॉयल्टी डैशबोर्ड</p>
        </div>
        <form onSubmit={submit} className="mt-8 rounded-2xl bg-card p-6 shadow-card">
          <label className="block text-xs font-semibold uppercase tracking-wider text-text-light">यूज़रनेम</label>
          <input
            type="text"
            autoComplete="username"
            required
            autoFocus
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="अपना यूज़रनेम डालें"
            className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 focus:border-accent focus:outline-none"
          />
          <label className="mt-5 block text-xs font-semibold uppercase tracking-wider text-text-light">पासवर्ड</label>
          <input
            type="password"
            autoComplete="current-password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="अपना पासवर्ड डालें"
            className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 focus:border-accent focus:outline-none"
          />
          <button
            disabled={busy}
            className="mt-6 w-full rounded-xl bg-primary py-3.5 font-semibold text-primary-foreground transition-transform active:scale-[0.98] disabled:opacity-60"
          >
            {busy ? "लॉगिन हो रहा है..." : "लॉगिन"}
          </button>
        </form>
      </div>
      <BrandFooter />
    </main>
  );
}
