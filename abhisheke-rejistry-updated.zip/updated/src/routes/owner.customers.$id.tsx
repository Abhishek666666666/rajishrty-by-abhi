import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { OwnerShell } from "@/components/OwnerShell";
import { LoyaltyCard } from "@/components/LoyaltyCard";
import { QRDisplay } from "@/components/QRDisplay";
import { createToken, scanUrl } from "@/lib/qr";
import { applyStampByToken } from "@/lib/stamp";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/owner/customers/$id")({ component: CustomerDetail });

interface Customer { id: string; name: string; mobile: string; aadhaar: string | null; customer_code: string; stamps: number; rewards_claimed: number; created_at: string; owner_id: string }
interface History { id: string; type: string; note: string | null; created_at: string }

function CustomerDetail() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const nav = useNavigate();
  const [c, setC] = useState<Customer | null>(null);
  const [history, setHistory] = useState<History[]>([]);
  const [settings, setSettings] = useState({ required_stamps: 5, reward_amount: 2000 });
  const [token, setToken] = useState<{ token: string; expiresAt: number } | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const [{ data: cust }, { data: s }] = await Promise.all([
      supabase.from("customers").select("*").eq("id", id).maybeSingle(),
      supabase.from("owner_settings").select("required_stamps,reward_amount").eq("owner_id", user.id).maybeSingle(),
    ]);
    if (cust) {
      setC(cust);
      const { data: h } = await supabase.from("stamp_history").select("id,type,note,created_at").eq("customer_id", cust.id).order("created_at", { ascending: false });
      setHistory(h ?? []);
    }
    if (s) setSettings(s);
    setLoading(false);
  }, [id, user]);

  useEffect(() => { load(); }, [load]);

  // Realtime
  useEffect(() => {
    if (!c) return;
    const ch = supabase.channel(`detail-${c.id}-${Date.now()}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "customers", filter: `id=eq.${c.id}` }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "stamp_history", filter: `customer_id=eq.${c.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [c, load]);

  async function generateQR() {
    if (!c) return;
    try {
      const t = await createToken(c);
      setToken(t);
    } catch (e: any) { toast.error(e.message); }
  }

  async function directStamp() {
    if (!token) return;
    const res = await applyStampByToken(token.token);
    if (!res.ok) {
      toast.error(res.error === "reward_pending" ? "Pehle reward claim karein" : "Stamp nahi laga");
      return;
    }
    toast.success(`✅ Stamp lag gaya — Registry #${res.customer.stamps}${res.reward_ready ? " · 🎉 Reward ready!" : ""}`);
    setToken(null);
  }

  async function claim() {
    if (!c) return;
    const { data, error } = await supabase.rpc("claim_reward", { p_customer_id: c.id });
    if (error) { toast.error(error.message); return; }
    const res = data as unknown as { ok: boolean; error?: string };
    if (!res.ok) { toast.error(res.error ?? "Error"); return; }
    toast.success(`✅ ₹${settings.reward_amount.toLocaleString("en-IN")} reward de diya. Naya cycle shuru!`);
  }

  async function deleteCustomer() {
    if (!c) return;
    if (!confirm(`Pakka delete karna hai "${c.name}" (${c.customer_code})?\nSaari history bhi delete ho jayegi.`)) return;
    await supabase.from("stamp_history").delete().eq("customer_id", c.id);
    await supabase.from("qr_tokens").delete().eq("customer_id", c.id);
    const { error } = await supabase.from("customers").delete().eq("id", c.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Customer delete ho gaya");
    nav({ to: "/owner/dashboard" });
  }

  async function approveBonusStamp(historyId: string) {
    if (!c) return;
    // Mark bonus_pending as bonus and add a stamp
    const [{ error: he }, { error: ce }] = await Promise.all([
      supabase.from("stamp_history").update({ type: "bonus", note: "Google Review बोनस स्टांप (ओनर द्वारा स्वीकृत)" }).eq("id", historyId),
      supabase.from("customers").update({ stamps: c.stamps + 1 }).eq("id", c.id),
    ]);
    if (he || ce) { toast.error("अपडेट नहीं हुआ"); return; }
    toast.success("✅ Google Review बोनस स्टांप दे दिया!");
    load();
  }

  async function editCode() {
    if (!c) return;
    const newCode = prompt("Naya customer code daalein:", c.customer_code);
    if (!newCode || newCode.trim() === c.customer_code) return;
    const { error } = await supabase.from("customers").update({ customer_code: newCode.trim().toUpperCase() }).eq("id", c.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Code update ho gaya");
    load();
  }
  if (loading) return <OwnerShell title="..." back="/owner/dashboard"><p className="text-text-light">Loading...</p></OwnerShell>;
  if (!c) return <OwnerShell title="Not found" back="/owner/dashboard"><p className="text-text-light">Customer nahi mila</p></OwnerShell>;

  const ready = c.stamps > 0 && c.stamps % settings.required_stamps === 0;

  return (
    <OwnerShell title={c.name} subtitle={c.customer_code} back="/owner/dashboard">
      <div className="space-y-5">
        <LoyaltyCard customer={c} required={settings.required_stamps} rewardAmount={settings.reward_amount} />

        {ready && (
          <div className="rounded-2xl bg-gradient-gold p-5 text-white shadow-gold">
            <p className="font-display text-xl">🎉 Reward Ready! ₹{settings.reward_amount.toLocaleString("en-IN")}</p>
            <p className="mt-1 text-sm text-white/90">Customer ko cash dein, phir click karein</p>
            <button onClick={claim} className="mt-3 w-full rounded-xl bg-success py-3 font-semibold text-white">
              ✅ Reward De Diya — Naya Cycle Shuru
            </button>
          </div>
        )}

        <section className="rounded-2xl bg-card p-5 shadow-card">
          <h3 className="font-display text-lg">QR Generate Karo</h3>
          <p className="mt-1 text-xs text-text-light">Owner ke phone se generate karo — customer ko dikhao ya scan karo</p>
          {!token ? (
            <button onClick={generateQR} disabled={ready} className="mt-4 w-full rounded-xl bg-primary py-3.5 font-semibold text-primary-foreground disabled:opacity-50">
              🔲 QR Generate Karo
            </button>
          ) : (
            <div className="mt-4 space-y-3">
              <QRDisplay token={token.token} url={scanUrl(token.token)} expiresAt={token.expiresAt} onExpire={() => setToken(null)} />
              <button onClick={directStamp} className="w-full rounded-xl bg-gradient-gold py-3 font-semibold text-white shadow-gold">
                🏷️ Seedha Stamp Lagao (single-device mode)
              </button>
            </div>
          )}
        </section>

        <section className="rounded-2xl bg-card p-5 shadow-card">
          <h3 className="font-display text-lg">Customer Info</h3>
          <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
            <Info l="Mobile" v={c.mobile} />
            <Info l="Aadhaar" v={c.aadhaar ?? "—"} />
            <Info l="Total Stamps" v={c.stamps} />
            <Info l="Rewards Liye" v={c.rewards_claimed} />
            <Info l="Registered" v={new Date(c.created_at).toLocaleDateString("en-IN", { dateStyle: "medium" })} />
          </dl>
          <div className="mt-5 flex gap-2">
            <button onClick={editCode} className="flex-1 rounded-xl border border-input bg-background py-2.5 text-sm font-medium text-text-mid hover:bg-muted">
              ✏️ Code Edit
            </button>
            <button onClick={deleteCustomer} className="flex-1 rounded-xl border border-destructive/30 bg-destructive/10 py-2.5 text-sm font-medium text-destructive hover:bg-destructive/20">
              🗑️ Delete Customer
            </button>
          </div>
        </section>

        {/* Feature 12: Pending bonus approvals */}
        {history.filter(h => h.type === "bonus_pending").length > 0 && (
          <section className="rounded-2xl bg-yellow-50 border-2 border-yellow-300 p-5">
            <h3 className="font-display text-lg text-yellow-800">⭐ बोनस स्टांप स्वीकृति</h3>
            <p className="mt-1 text-xs text-yellow-700">ग्राहक ने Google Review दिया है — स्वीकृति दें</p>
            <div className="mt-3 space-y-2">
              {history.filter(h => h.type === "bonus_pending").map(h => (
                <div key={h.id} className="flex items-center justify-between rounded-xl bg-white border border-yellow-200 px-4 py-3">
                  <div>
                    <p className="text-sm font-medium">{h.note ?? "Google Review बोनस"}</p>
                    <p className="text-xs text-text-light">{new Date(h.created_at).toLocaleString("hi-IN", { dateStyle: "medium", timeStyle: "short" })}</p>
                  </div>
                  <button onClick={() => approveBonusStamp(h.id)} className="rounded-lg bg-yellow-500 px-3 py-1.5 text-xs font-bold text-white">
                    ✅ स्वीकृत करें
                  </button>
                </div>
              ))}
            </div>
          </section>
        )}

        <section className="rounded-2xl bg-card p-5 shadow-card">
          <h3 className="font-display text-lg">History</h3>
          {history.length === 0 ? (
            <p className="mt-3 text-sm text-text-light">Abhi koi entry nahi</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {history.map((h) => (
                <li key={h.id} className="flex items-start gap-3">
                  <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${h.type === "reward" ? "bg-success" : "bg-accent"}`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-text-mid">{h.note ?? h.type}</p>
                    <p className="text-xs text-text-light">{new Date(h.created_at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </OwnerShell>
  );
}

function Info({ l, v }: { l: string; v: string | number }) {
  return (
    <div>
      <dt className="text-[10px] uppercase tracking-wider text-text-light">{l}</dt>
      <dd className="mt-0.5 font-medium text-text-mid">{v}</dd>
    </div>
  );
}
