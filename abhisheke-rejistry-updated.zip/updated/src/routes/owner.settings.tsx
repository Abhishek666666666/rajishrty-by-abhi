import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { OwnerShell } from "@/components/OwnerShell";
import { useAuth } from "@/lib/auth";
import { invalidateBrand } from "@/lib/brand";

export const Route = createFileRoute("/owner/settings")({ component: Settings });

function Settings() {
  const { user } = useAuth();
  const [office, setOffice] = useState("");
  const [brand, setBrand] = useState("");
  const [tagline, setTagline] = useState("");
  const [watermark, setWatermark] = useState("");
  const [address, setAddress] = useState("");
  const [supportPhone, setSupportPhone] = useState("");
  const [reward, setReward] = useState(2000);
  const [required, setRequired] = useState(5);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const userId = user?.id;
  useEffect(() => {
    if (!userId) return;
    supabase.from("owner_settings").select("*").eq("owner_id", userId).maybeSingle().then(({ data }) => {
      if (data) {
        setOffice(data.office_name || "");
        setBrand(data.brand_name || "");
        setTagline(data.tagline || "");
        setWatermark(data.watermark || "");
        setAddress(data.address || "");
        setSupportPhone(data.support_phone || "");
        setReward(data.reward_amount);
        setRequired(data.required_stamps);
      }
    });
  }, [userId]);

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("owner_settings").upsert({
      owner_id: user.id,
      office_name: office,
      brand_name: brand,
      tagline,
      watermark,
      address,
      support_phone: supportPhone,
      reward_amount: reward,
      required_stamps: required,
      updated_at: new Date().toISOString(),
    });
    setBusy(false);
    if (error) toast.error(error.message);
    else {
      invalidateBrand();
      window.dispatchEvent(new Event("brand-settings-updated"));
      toast.success("Settings save ho gayi ✓");
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) { toast.error("Min 6 chars"); return; }
    const { error } = await supabase.auth.updateUser({ password });
    if (error) toast.error(error.message);
    else { toast.success("Password change ho gaya"); setPassword(""); }
  }

  function resetDefaults() {
    if (!confirm("Saare brand names default pe reset karna hai?")) return;
    setBrand("अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय");
    setTagline("हर रजिस्ट्री पर स्टांप, 5 स्टांप पर ₹2,000 इनाम");
    setWatermark("Made by Abhishek Sharma from Agar");
    setAddress("आगर मालवा, मध्य प्रदेश");
    setOffice("E-Registry");
  }

  return (
    <OwnerShell title="Settings" back="/owner/dashboard">
      <form onSubmit={saveSettings} className="rounded-2xl bg-card p-6 shadow-card">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-lg">Brand & Identity</h3>
          <button type="button" onClick={resetDefaults} className="rounded-full bg-muted px-3 py-1 text-[11px] text-text-light hover:text-primary">↺ Reset</button>
        </div>
        <p className="mt-1 text-xs text-text-light">Yeh sab text customer pages pe dikhega — kabhi bhi badal sakte ho</p>

        <Field label="Brand Name (header)">
          <textarea value={brand} onChange={(e) => setBrand(e.target.value)} rows={2} className="input" />
        </Field>
        <Field label="Tagline (homepage)">
          <input value={tagline} onChange={(e) => setTagline(e.target.value)} className="input" />
        </Field>
        <Field label="Address / Location">
          <input value={address} onChange={(e) => setAddress(e.target.value)} className="input" />
        </Field>
        <Field label="Support Phone (optional)">
          <input value={supportPhone} onChange={(e) => setSupportPhone(e.target.value.replace(/[^\d+\- ]/g, ""))} className="input" placeholder="+91 ..." />
        </Field>
        <Field label="Watermark (footer)">
          <input value={watermark} onChange={(e) => setWatermark(e.target.value)} className="input" />
        </Field>
        <Field label="Office Name (dashboard title)">
          <input value={office} onChange={(e) => setOffice(e.target.value)} className="input" />
        </Field>

        <h3 className="mt-6 font-display text-lg">Loyalty Rules</h3>
        <div className="mt-2 grid grid-cols-2 gap-3">
          <Field label="Reward (₹)">
            <input type="number" min={100} value={reward} onChange={(e) => setReward(Number(e.target.value))} className="input" />
          </Field>
          <Field label="Required Stamps">
            <input type="number" min={1} max={20} value={required} onChange={(e) => setRequired(Number(e.target.value))} className="input" />
          </Field>
        </div>

        <button disabled={busy} className="mt-5 w-full rounded-xl bg-gradient-gold py-3 font-semibold text-white shadow-gold disabled:opacity-60">
          {busy ? "Saving..." : "✓ Save All Settings"}
        </button>
      </form>

      <form onSubmit={changePassword} className="mt-5 rounded-2xl bg-card p-6 shadow-card">
        <h3 className="font-display text-lg">Change Password</h3>
        <input type="password" minLength={6} placeholder="New password" value={password} onChange={(e) => setPassword(e.target.value)} className="input mt-3" />
        <button className="mt-4 w-full rounded-xl bg-primary py-3 font-semibold text-primary-foreground">Update Password</button>
      </form>

      <style>{`.input { margin-top:.5rem; width:100%; border-radius:.75rem; border:1px solid var(--input); background: var(--background); padding:.65rem .9rem; outline:none; font-size: .95rem; } .input:focus { border-color: var(--accent); }`}</style>
    </OwnerShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mt-3 block">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-text-light">{label}</span>
      {children}
    </label>
  );
}
