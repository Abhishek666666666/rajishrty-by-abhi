import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { OwnerShell } from "@/components/OwnerShell";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/owner/customers/new")({ component: NewCustomer });

function NewCustomer() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [aadhaar, setAadhaar] = useState("");
  const [customCode, setCustomCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (mobile.length !== 10) { toast.error("10-digit mobile number दालें"); return; }
    setBusy(true);
    let code: string;
    if (customCode.trim()) {
      code = customCode.trim().toUpperCase();
    } else {
      const { data: codeData, error: codeErr } = await supabase.rpc("next_customer_code", { p_owner: user.id });
      if (codeErr || !codeData) { toast.error("Code generate नहीं हुआ"); setBusy(false); return; }
      code = codeData as string;
    }
    const { data, error } = await supabase
      .from("customers")
      .insert({ name: name.trim(), mobile, aadhaar: aadhaar || null, customer_code: code, owner_id: user.id })
      .select("id")
      .single();
    setBusy(false);
    if (error) {
      if (error.code === "23505") toast.error("यह मोबाइल पहले से रजिस्टर है");
      else toast.error(error.message);
      return;
    }
    setGeneratedCode(code);
    toast.success(`✅ ${name} जोड़े गए! कोड: ${code}`);
  }

  function copyCode() {
    if (!generatedCode) return;
    navigator.clipboard.writeText(generatedCode).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function shareCode() {
    if (!generatedCode) return;
    const msg = encodeURIComponent(`नमस्ते! आपका अभिषेक E-Registry लॉयल्टी कोड है: ${generatedCode}\nमोबाइल नंबर और इस कोड से लॉगिन करें।`);
    window.open(`https://wa.me/?text=${msg}`, "_blank");
  }

  // Show success screen after adding customer
  if (generatedCode) {
    return (
      <OwnerShell title="नया ग्राहक" subtitle="जोड़ा गया ✅" back="/owner/dashboard">
        <div className="rounded-2xl bg-card p-6 shadow-card text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-gold text-3xl shadow-gold">✅</div>
          <h2 className="mt-4 font-display text-2xl">{name}</h2>
          <p className="mt-1 text-sm text-text-light">सफलतापूर्वक जोड़े गए</p>

          <div className="mt-6 rounded-2xl bg-primary/5 border-2 border-primary/20 p-5">
            <p className="text-xs uppercase tracking-wider text-text-light mb-2">ग्राहक कोड</p>
            <p className="font-mono text-4xl font-bold text-primary tracking-widest">{generatedCode}</p>
            <p className="mt-2 text-xs text-text-light">यह कोड ग्राहक को दें</p>
          </div>

          <div className="mt-4 flex gap-3">
            <button
              onClick={copyCode}
              className="flex-1 rounded-xl border-2 border-accent/30 bg-accent/10 py-3 text-sm font-semibold text-accent transition-transform active:scale-[0.98]"
            >
              {copied ? "✅ कॉपी हुआ!" : "📋 कोड कॉपी करें"}
            </button>
            <button
              onClick={shareCode}
              className="flex-1 rounded-xl bg-[#25D366] py-3 text-sm font-semibold text-white transition-transform active:scale-[0.98]"
            >
              💬 WhatsApp करें
            </button>
          </div>

          <button
            onClick={() => nav({ to: "/owner/dashboard" })}
            className="mt-4 w-full rounded-xl bg-primary py-3.5 font-semibold text-primary-foreground"
          >
            डैशबोर्ड पर वापस जाएं
          </button>
        </div>
      </OwnerShell>
    );
  }

  return (
    <OwnerShell title="नया ग्राहक" subtitle="जोड़ें" back="/owner/dashboard">
      <form onSubmit={submit} className="rounded-2xl bg-card p-6 shadow-card">
        <Field label="पूरा नाम" required>
          <input value={name} onChange={(e) => setName(e.target.value)} required className="input" placeholder="राम कुमार" />
        </Field>
        <Field label="मोबाइल नंबर" required>
          <input
            value={mobile}
            onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
            required inputMode="numeric" placeholder="9876543210" className="input"
          />
        </Field>
        <Field label="आधार / वोटर ID (वैकल्पिक)">
          <input value={aadhaar} onChange={(e) => setAadhaar(e.target.value)} className="input" placeholder="XXXX XXXX XXXX" />
        </Field>
        <Field label="कस्टम कोड (वैकल्पिक — खाली छोड़ें तो ऑटो)">
          <input value={customCode} onChange={(e) => setCustomCode(e.target.value.toUpperCase())} className="input" placeholder="खाली छोड़ें = REG-XXXX ऑटो मिलेगा" maxLength={20} />
        </Field>
        <div className="mt-4 rounded-xl bg-accent/10 border border-accent/20 px-4 py-3 text-xs text-accent">
          💡 कोड ऑटो जनरेट होगा — सेव होने के बाद स्क्रीन पर दिखेगा जिसे आप कॉपी या WhatsApp कर सकते हैं।
        </div>
        <button disabled={busy} className="mt-4 w-full rounded-xl bg-gradient-gold py-3.5 font-semibold text-white shadow-gold disabled:opacity-60">
          {busy ? "जोड़ा जा रहा है..." : "✓ ग्राहक जोड़ें"}
        </button>
      </form>
      <style>{`.input { margin-top:.5rem; width:100%; border-radius:.75rem; border:1px solid var(--input); background: var(--background); padding:.75rem 1rem; outline:none; } .input:focus { border-color: var(--accent); }`}</style>
    </OwnerShell>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="mt-3 block first:mt-0">
      <span className="text-xs font-semibold uppercase tracking-wider text-text-light">{label}{required && " *"}</span>
      {children}
    </label>
  );
}
