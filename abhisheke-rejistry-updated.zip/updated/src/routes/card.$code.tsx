import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { LoyaltyCard } from "@/components/LoyaltyCard";
import { QRDisplay } from "@/components/QRDisplay";
import { createToken, scanUrl } from "@/lib/qr";
import { BrandHeader } from "@/components/BrandHeader";
import { BrandFooter } from "@/components/BrandFooter";
import { toast } from "sonner";

export const Route = createFileRoute("/card/$code")({ component: CardPage });

interface Customer { id: string; name: string; customer_code: string; stamps: number; owner_id: string }
interface History { id: string; type: string; note: string | null; created_at: string }

const WHATSAPP_OWNER = "919926653319";
const HOME_URL = typeof window !== "undefined" ? window.location.origin : "https://abhishek-eregistry.com";
const GOOGLE_REVIEW_URL = "https://g.page/r/review"; // Replace with actual Google review URL

function CardPage() {
  const { code } = Route.useParams();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [settings, setSettings] = useState<{ required_stamps: number; reward_amount: number } | null>(null);
  const [history, setHistory] = useState<History[]>([]);
  const [token, setToken] = useState<{ token: string; expiresAt: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [bonusPending, setBonusPending] = useState(false);
  const tokenBusy = useRef(false);

  const load = useCallback(async () => {
    const { data: c } = await supabase
      .from("customers")
      .select("id,name,customer_code,stamps,owner_id")
      .eq("customer_code", code)
      .maybeSingle();
    if (!c) { setLoading(false); return; }
    setCustomer(c);
    const [{ data: s }, { data: h }] = await Promise.all([
      supabase.from("owner_settings").select("required_stamps,reward_amount").eq("owner_id", c.owner_id).maybeSingle(),
      supabase.from("stamp_history").select("id,type,note,created_at").eq("customer_id", c.id).order("created_at", { ascending: true }).limit(50),
    ]);
    setSettings(s ?? { required_stamps: 5, reward_amount: 2000 });
    setHistory(h ?? []);
    setLoading(false);
  }, [code]);

  const refreshToken = useCallback(async () => {
    if (!customer || tokenBusy.current) return;
    tokenBusy.current = true;
    try {
      const t = await createToken(customer);
      setToken(t);
    } catch (e) { console.error(e); }
    finally { tokenBusy.current = false; }
  }, [customer]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (customer && !token) refreshToken(); }, [customer, token, refreshToken]);

  useEffect(() => {
    if (!customer) return;
    const ch = supabase
      .channel(`cust-${customer.id}-${Date.now()}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "customers", filter: `id=eq.${customer.id}` }, () => load())
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "stamp_history", filter: `customer_id=eq.${customer.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [customer, load]);

  function handleClaimReward() {
    if (!customer) return;
    const msg = encodeURIComponent(`🎁 ${customer.name} (Code: ${customer.customer_code}) is claiming their ₹${settings?.reward_amount?.toLocaleString("en-IN") ?? "2,000"} reward!`);
    window.open(`https://wa.me/${WHATSAPP_OWNER}?text=${msg}`, "_blank");
  }

  function handleShare() {
    const msg = encodeURIComponent(`मैंने अभिषेक E-Registry में रजिस्ट्री करवाई और ₹2,000 जीतने का मौका मिला! तुम भी आओ: ${HOME_URL}`);
    window.open(`https://wa.me/?text=${msg}`, "_blank");
  }

  function handleGoogleReview() {
    if (!customer) return;
    window.open(GOOGLE_REVIEW_URL, "_blank");
    setBonusPending(true);
    // Insert pending bonus stamp in history
    supabase.from("stamp_history").insert({
      customer_id: customer.id,
      type: "bonus_pending",
      note: "Google Review बोनस स्टांप (ओनर की स्वीकृति बाकी)",
    }).then(() => {
      toast.success("✅ Google Review खोला गया! बोनस स्टांप ओनर की स्वीकृति के बाद मिलेगा।");
    });
  }

  if (loading) return (
    <main className="flex min-h-screen flex-col bg-background">
      <BrandHeader back="/customer" />
      <div className="flex flex-1 items-center justify-center"><p className="text-text-light">लोड हो रहा है...</p></div>
      <BrandFooter />
    </main>
  );
  if (!customer) return (
    <main className="flex min-h-screen flex-col bg-background">
      <BrandHeader back="/customer" />
      <div className="flex flex-1 items-center justify-center px-5 text-center">
        <div>
          <p className="font-display text-2xl">ग्राहक नहीं मिला</p>
          <Link to="/customer" className="mt-4 inline-block rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground">वापस</Link>
        </div>
      </div>
      <BrandFooter />
    </main>
  );

  const required = settings?.required_stamps ?? 5;
  const reward = settings?.reward_amount ?? 2000;
  const ready = customer.stamps > 0 && customer.stamps % required === 0;

  // Build stamp slots with dates from history
  const stampEntries = history.filter(h => h.type === "stamp" || h.type === "bonus");
  const inCycle = customer.stamps % required;
  const cycleStamps = ready ? required : inCycle;

  return (
    <main className="flex min-h-screen flex-col bg-background animate-page-in">
      {/* Fix 2: Hide Lovable badge */}
      <style>{`[data-lovable-badge], #lovable-badge, .lovable-badge, iframe[src*="lovable"] { display: none !important; }`}</style>

      <BrandHeader back="/customer" />

      <div className="mx-auto w-full max-w-md flex-1 space-y-5 px-5 py-6">
        <LoyaltyCard customer={customer} required={required} rewardAmount={reward} />

        {/* Feature 6: Stamp history with glowing circles */}
        <section className="rounded-2xl bg-card p-5 shadow-card">
          <h3 className="font-display text-lg mb-4">स्टांप इतिहास</h3>
          <div className="flex flex-wrap gap-3 justify-center">
            {Array.from({ length: required }).map((_, i) => {
              const entry = stampEntries[i];
              const earned = i < cycleStamps;
              const date = entry ? new Date(entry.created_at).toLocaleDateString("hi-IN", { day: "numeric", month: "short", year: "2-digit" }) : null;
              return (
                <div key={i} className="flex flex-col items-center gap-1.5">
                  <div
                    className={[
                      "h-14 w-14 rounded-full flex items-center justify-center text-xl font-bold transition-all",
                      earned
                        ? "bg-gradient-gold text-white shadow-[0_0_18px_4px_rgba(201,146,43,0.45)]"
                        : "border-2 border-dashed border-border bg-muted text-text-light",
                    ].join(" ")}
                  >
                    {earned ? "✓" : <span className="text-base opacity-40">{i + 1}</span>}
                  </div>
                  <span className="text-[10px] text-center text-text-light leading-tight">
                    {earned && date ? `${i + 1} – ${date}` : `स्टांप ${i + 1}`}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* Feature 7: Claim reward button */}
        {ready && (
          <div className="rounded-2xl bg-gradient-gold p-5 text-center text-white shadow-gold">
            <p className="text-3xl">🎉</p>
            <p className="mt-1 font-display text-xl font-bold">इनाम तैयार है!</p>
            <p className="mt-1 font-display text-3xl font-bold">₹{reward.toLocaleString("en-IN")}</p>
            <button
              onClick={handleClaimReward}
              className="mt-4 w-full rounded-xl bg-white py-3.5 font-bold text-accent text-base transition-transform active:scale-[0.98] shadow-md"
            >
              🎁 ₹{reward.toLocaleString("en-IN")} इनाम क्लेम करें
            </button>
            <p className="mt-2 text-xs text-white/80">बटन दबाने पर WhatsApp पर ओनर को मैसेज जाएगा</p>
          </div>
        )}

        {token && !ready && (
          <QRDisplay
            token={token.token}
            url={scanUrl(token.token)}
            expiresAt={token.expiresAt}
            onExpire={refreshToken}
          />
        )}

        {/* Feature 8: Share with a Friend */}
        <button
          onClick={handleShare}
          className="w-full rounded-2xl border-2 border-[#25D366] bg-[#25D366]/10 py-3.5 font-semibold text-[#25D366] text-sm transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
        >
          💬 दोस्त को Share करें — ₹2,000 जीतने का मौका
        </button>

        {/* Feature 12: Google Review Bonus */}
        <button
          onClick={handleGoogleReview}
          disabled={bonusPending}
          className="w-full rounded-2xl border-2 border-accent/40 bg-accent/10 py-3.5 font-semibold text-accent text-sm transition-transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-60"
        >
          ⭐ Google Review देकर 1 Bonus Stamp पाएं
          {bonusPending && <span className="text-xs font-normal text-text-light">(बाकी है)</span>}
        </button>

        <section className="rounded-2xl bg-card p-5 shadow-card">
          <h3 className="font-display text-lg">विज़िट इतिहास</h3>
          {history.length === 0 ? (
            <p className="mt-3 text-sm text-text-light">अभी कोई विज़िट नहीं</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {[...history].reverse().map((h) => (
                <li key={h.id} className="flex items-start gap-3">
                  <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${h.type === "reward" ? "bg-success" : h.type === "bonus_pending" ? "bg-yellow-500" : "bg-accent"}`} />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-text-mid">{h.note ?? h.type}</p>
                    <p className="text-xs text-text-light">{new Date(h.created_at).toLocaleString("hi-IN", { dateStyle: "medium", timeStyle: "short" })}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
      <BrandFooter />
    </main>
  );
}
