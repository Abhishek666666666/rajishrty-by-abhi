import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { Toaster } from "sonner";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-bold text-primary">404</h1>
        <p className="mt-3 text-text-light">पेज नहीं मिला</p>
        <Link to="/" className="mt-6 inline-block rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground">होम जाएँ</Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error }: { error: Error; reset: () => void }) {
  console.error(error);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-2xl text-primary">Kuch galat ho gaya</h1>
        <p className="mt-2 text-sm text-text-light">{error.message}</p>
        <a href="/" className="mt-6 inline-block rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground">Wapas Jaao</a>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय — लॉयल्टी" },
      { name: "description", content: "हर रजिस्ट्री पर डिजिटल स्टांप, 5 स्टांप पर ₹2,000 नकद इनाम।" },
      { name: "theme-color", content: "#0a0f1e" },
      { property: "og:title", content: "अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय — लॉयल्टी" },
      { name: "twitter:title", content: "अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय — लॉयल्टी" },
      { property: "og:description", content: "हर रजिस्ट्री पर डिजिटल स्टांप, 5 स्टांप पर ₹2,000 नकद इनाम।" },
      { name: "twitter:description", content: "हर रजिस्ट्री पर डिजिटल स्टांप, 5 स्टांप पर ₹2,000 नकद इनाम।" },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/f0af31d0-e191-4327-aeca-ee36d5d9f8af" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/f0af31d0-e191-4327-aeca-ee36d5d9f8af" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800&family=Outfit:wght@300;400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="hi">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      {/* Fix 2: Hide Lovable badge globally from public users */}
      <style>{`[data-lovable-badge], #lovable-badge, .lovable-badge, iframe[src*="lovable"], a[href*="lovable.dev"] { display: none !important; visibility: hidden !important; }`}</style>
      <Outlet />
      <Toaster position="bottom-center" toastOptions={{ className: "font-sans" }} richColors />
    </QueryClientProvider>
  );
}
