import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StampCircles } from "@/components/StampCircles";
import { BrandHeader } from "@/components/BrandHeader";
import { BrandFooter } from "@/components/BrandFooter";
import { useBrand } from "@/lib/brand";

export const Route = createFileRoute("/scan/$token")({ component: ScanPage });

interface Customer { name: string; customer_code: string; stamps: number; owner_id: string }

function ScanPage() {
  const { token } = Route.useParams();
  const brand = useBrand();
  const [state, setState] = useState<"loading" | "success" | "error">("loading");
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [rewardReady, setRewardReady] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [required, setRequired] = useState(5);
  const [rewardAmount, setRewardAmount] = useState(2000);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.rpc("apply_stamp_by_token", { p_token: token });
      if (error) { setErrorMsg(error.message); setState("error"); return; }
      const res = data as unknown as { ok: boolean; error?: string; customer?: Customer; reward_ready?: boolean };
      if (!res.ok) {
        const msg = res.error === "expired" ? "QR की अवधि समाप्त — नया जनरेट करें"
          : res.error === "already_used" ? "यह QR पहले ही उपयोग हो चुका है"
          : res.error === "reward_pending" ? "पहले इनाम क्लेम करें!"
          : res.error === "not_found" ? "अमान्य QR कोड"
          : "कुछ गलत हो गया";
        setErrorMsg(msg);
        if (res.customer) setCustomer(res.customer);
        setState("error");
        return;
      }
      setCustomer(res.customer!);
      setRewardReady(!!res.reward_ready);
      if (res.customer) {
        const { data: s } = await supabase.from("owner_settings").select("required_stamps,reward_amount").eq("owner_id", res.customer.owner_id).maybeSingle();
        if (s) { setRequired(s.required_stamps); setRewardAmount(s.reward_amount); }
      }
      setState("success");
    })();
  }, [token]);

  if (state === "loading") {
    return (
      <main className="flex min-h-screen flex-col bg-primary text-white">
        <BrandHeader />
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-accent border-t-transparent" />
            <p className="mt-4 text-white/70">स्टांप लग रहा है...</p>
          </div>
        </div>
        <BrandFooter dark />
      </main>
    );
  }

  if (state === "error") {
    return (
      <main className="flex min-h-screen flex-col bg-primary text-white">
        <BrandHeader />
        <div className="flex flex-1 items-center justify-center px-5">
          <div className="w-full max-w-sm rounded-2xl bg-white/5 p-8 text-center ring-1 ring-white/10 animate-page-in">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-destructive/20 text-3xl">⚠️</div>
            <h1 className="mt-5 font-display text-2xl">स्टांप नहीं लगा</h1>
            <p className="mt-2 text-white/70">{errorMsg}</p>
            {customer && <p className="mt-4 font-mono text-xs text-accent-light">{customer.customer_code} · {customer.name}</p>}
            <Link to="/" className="mt-6 inline-block rounded-full bg-white/10 px-5 py-2 text-sm">← वापस</Link>
          </div>
        </div>
        <BrandFooter dark />
      </main>
    );
  }

  const cycleStamps = customer!.stamps % required === 0 ? required : customer!.stamps % required;

  return (
    <main className="relative flex min-h-screen flex-col overflow-hidden bg-primary text-white">
      {rewardReady && <Confetti />}
      <BrandHeader />
      <div className="relative flex flex-1 items-center justify-center px-5 py-6">
        <div className="relative w-full max-w-sm rounded-2xl bg-white/5 p-7 text-center ring-1 ring-white/10 animate-page-in">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-success/20 text-5xl animate-stamp">✅</div>
          <h1 className="mt-5 font-display text-3xl">स्टांप लग गया!</h1>
          <p className="mt-1 text-accent-light">{customer!.name}</p>
          <p className="font-mono text-xs text-white/60">{customer!.customer_code}</p>

          <div className="mt-6">
            <StampCircles filled={cycleStamps} total={required} size="lg" animateLast />
          </div>
          <p className="mt-4 text-sm text-white/70">रजिस्ट्री #{customer!.stamps} पूरी</p>

          {rewardReady && (
            <div className="mt-6 rounded-xl bg-gradient-gold p-5 text-white shadow-gold">
              <p className="text-3xl">🎉</p>
              <p className="mt-1 font-display text-2xl font-bold">₹{rewardAmount.toLocaleString("en-IN")} इनाम मिला!</p>
              <p className="mt-1 text-sm text-white/90">{brand.brand_name} से ₹{rewardAmount.toLocaleString("en-IN")} नकद लें</p>
            </div>
          )}

          <Link to="/" className="mt-7 inline-block rounded-full bg-white/10 px-6 py-2.5 text-sm">← वापस जाएँ</Link>
        </div>
      </div>
      <BrandFooter dark />
    </main>
  );
}

function Confetti() {
  const pieces = Array.from({ length: 14 }).map((_, i) => {
    const angle = (Math.PI * 2 * i) / 14;
    const dist = 180 + Math.random() * 80;
    const colors = ["#c9922b", "#e8b84b", "#fdf3de", "#ffffff"];
    return (
      <span
        key={i}
        className="confetti-piece absolute left-1/2 top-1/2 h-3 w-3 rounded-sm"
        style={{
          backgroundColor: colors[i % colors.length],
          // @ts-expect-error css vars
          "--tx": `${Math.cos(angle) * dist}px`,
          "--ty": `${Math.sin(angle) * dist}px`,
          animationDelay: `${i * 30}ms`,
        }}
      />
    );
  });
  return <div className="pointer-events-none absolute inset-0">{pieces}</div>;
}
