import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { OwnerShell } from "@/components/OwnerShell";
import { QRScanner } from "@/components/QRScanner";
import { applyStampByToken } from "@/lib/stamp";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/owner/dashboard")({ component: Dashboard });

interface Customer { id: string; name: string; customer_code: string; mobile: string; stamps: number; rewards_claimed: number }

function Dashboard() {
  const { user } = useAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [settings, setSettings] = useState({ required_stamps: 5, reward_amount: 2000, office_name: "E-Registry" });
  const [tab, setTab] = useState<"all" | "ready" | "scan">("all");
  const [search, setSearch] = useState("");
  const [stampingId, setStampingId] = useState<string | null>(null);

  const userId = user?.id;
  useEffect(() => {
    if (!userId) return;
    (async () => {
      const [{ data: cs }, { data: s }] = await Promise.all([
        supabase.from("customers").select("id,name,customer_code,mobile,stamps,rewards_claimed").eq("owner_id", userId).order("created_at", { ascending: false }),
        supabase.from("owner_settings").select("required_stamps,reward_amount,office_name").eq("owner_id", userId).maybeSingle(),
      ]);
      setCustomers(cs ?? []);
      if (s) setSettings(s);
    })();

    const ch = supabase
      .channel(`owner-customers-${userId}-${Date.now()}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "customers", filter: `owner_id=eq.${userId}` }, async () => {
        const { data } = await supabase.from("customers").select("id,name,customer_code,mobile,stamps,rewards_claimed").eq("owner_id", userId).order("created_at", { ascending: false });
        setCustomers(data ?? []);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [userId]);

  const required = settings.required_stamps;
  const reward = settings.reward_amount;

  // Feature 9: Summary stats
  const stats = useMemo(() => ({
    total: customers.length,
    stamps: customers.reduce((a, c) => a + c.stamps, 0),
    rewards: customers.reduce((a, c) => a + c.rewards_claimed, 0),
    payout: customers.reduce((a, c) => a + c.rewards_claimed, 0) * reward,
  }), [customers, reward]);

  const readyList = customers.filter((c) => c.stamps > 0 && c.stamps % required === 0);
  const filtered = customers.filter((c) =>
    !search ||
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.customer_code.toLowerCase().includes(search.toLowerCase()) ||
    c.mobile.includes(search)
  ).sort((a, b) => {
    const aR = a.stamps > 0 && a.stamps % required === 0 ? 1 : 0;
    const bR = b.stamps > 0 && b.stamps % required === 0 ? 1 : 0;
    return bR - aR;
  });

  async function handleScan(text: string) {
    try {
      const res = await applyStampByToken(text);
      if (!res.ok) {
        toast.error(res.error === "expired" ? "QR expire ho gaya" : res.error === "already_used" ? "Pehle hi use ho gaya" : res.error === "reward_pending" ? "Pehle reward claim karein" : "Invalid QR");
        return;
      }
      toast.success(`✅ ${res.customer.name} — Registry #${res.customer.stamps}${res.reward_ready ? " · 🎉 Reward ready!" : ""}`);
    } catch (e: any) {
      toast.error(e.message ?? "Error");
    }
  }

  // Feature 11: Direct stamp button
  async function addStamp(c: Customer) {
    if (stampingId) return;
    setStampingId(c.id);
    try {
      const newStamps = c.stamps + 1;
      const { error } = await supabase
        .from("customers")
        .update({ stamps: newStamps })
        .eq("id", c.id);
      if (error) { toast.error(error.message); return; }

      await supabase.from("stamp_history").insert({
        customer_id: c.id,
        type: "stamp",
        note: `स्टांप #${newStamps} — ओनर द्वारा (Manual)`,
      });

      const rewardReady = newStamps > 0 && newStamps % required === 0;
      toast.success(`✅ ${c.name} को स्टांप #${newStamps} मिला!${rewardReady ? " 🎉 इनाम तैयार!" : ""}`);
    } finally {
      setStampingId(null);
    }
  }

  return (
    <OwnerShell
      title={settings.office_name || "E-Registry Owner"}
      subtitle="Dashboard"
      right={
        <div className="flex items-center gap-2">
          <Link to="/owner/settings" className="rounded-full bg-white/10 px-3 py-1.5 text-xs hover:bg-white/20" title="Settings">⚙️</Link>
          <Link to="/owner/customers/new" className="rounded-full bg-gradient-gold px-3 py-1.5 text-xs font-semibold text-white shadow-gold">
            ➕ Customer
          </Link>
        </div>
      }
    >
      {/* Feature 9: Summary cards */}
      <div className="grid grid-cols-2 gap-3">
        <Stat label="कुल ग्राहक" value={stats.total} icon="👥" />
        <Stat label="कुल स्टांप" value={stats.stamps} icon="🏷️" />
        <Stat label="इनाम दिए" value={stats.rewards} icon="🎁" />
        <Stat label="कुल भुगतान" value={`₹${stats.payout.toLocaleString("en-IN")}`} icon="💰" />
      </div>

      <div className="mt-6 flex gap-1 rounded-xl bg-muted p-1 text-sm">
        {([
          ["all", `ग्राहक (${customers.length})`],
          ["ready", `इनाम (${readyList.length})`],
          ["scan", "QR Scanner"],
        ] as const).map(([k, l]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`flex-1 rounded-lg px-2 py-2 text-xs font-medium transition-colors ${tab === k ? "bg-card text-primary shadow-sm" : "text-text-light"}`}
          >{l}</button>
        ))}
      </div>

      <div className="mt-5">
        {tab === "all" && (
          <div className="space-y-3">
            {/* Feature 9: Searchable list */}
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="🔍 नाम, कोड, मोबाइल से खोजें..."
              className="w-full rounded-xl border border-input bg-card px-4 py-3 text-sm shadow-card focus:border-accent focus:outline-none"
            />
            {filtered.length === 0 ? (
              <Empty msg={customers.length === 0 ? "अभी कोई ग्राहक नहीं — ➕ से जोड़ें" : "कोई परिणाम नहीं मिला"} />
            ) : (
              filtered.map((c) => (
                <CustomerRowWithStamp
                  key={c.id}
                  c={c}
                  required={required}
                  rewardAmount={reward}
                  onAddStamp={() => addStamp(c)}
                  stamping={stampingId === c.id}
                />
              ))
            )}
          </div>
        )}
        {tab === "ready" && (
          <div className="space-y-3">
            {readyList.length === 0 ? <Empty msg="कोई इनाम तैयार नहीं" /> : readyList.map((c) => (
              <CustomerRowWithStamp
                key={c.id}
                c={c}
                required={required}
                rewardAmount={reward}
                onAddStamp={() => addStamp(c)}
                stamping={stampingId === c.id}
              />
            ))}
          </div>
        )}
        {tab === "scan" && (
          <div className="rounded-2xl bg-card p-5 shadow-card">
            <h3 className="font-display text-lg">QR Scanner</h3>
            <p className="mt-1 text-sm text-text-light">ग्राहक का QR कैमरे पर रखें — ऑटो स्टांप लग जाएगा</p>
            <div className="mt-4">
              <QRScanner onResult={handleScan} />
            </div>
            <div className="mt-5 border-t pt-4">
              <p className="text-xs uppercase tracking-wider text-text-light">Manual token</p>
              <ManualToken onSubmit={handleScan} />
            </div>
          </div>
        )}
      </div>
    </OwnerShell>
  );
}

// Feature 11: Customer row with + Stamp button
function CustomerRowWithStamp({ c, required, rewardAmount, onAddStamp, stamping }: {
  c: Customer; required: number; rewardAmount: number; onAddStamp: () => void; stamping: boolean;
}) {
  const ready = c.stamps > 0 && c.stamps % required === 0;
  const cycle = ready ? required : c.stamps % required;
  const initials = c.name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div className="flex items-center gap-3">
        <Link
          to="/owner/customers/$id"
          params={{ id: c.id }}
          className="flex items-center gap-3 flex-1 min-w-0"
        >
          <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl font-display text-base font-bold text-white ${ready ? "bg-gradient-gold shadow-gold" : "bg-primary"}`}>
            {initials}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="truncate font-medium">{c.name}</p>
              {ready && <span className="rounded-full bg-accent-pale px-2 py-0.5 text-[10px] font-semibold text-accent">🎁 ₹{rewardAmount}</span>}
            </div>
            <p className="font-mono text-xs text-text-light">{c.customer_code} · {c.mobile}</p>
            <p className="text-xs text-text-light mt-0.5">{cycle}/{required} स्टांप</p>
          </div>
        </Link>
        <button
          onClick={onAddStamp}
          disabled={stamping || ready}
          className="shrink-0 rounded-xl bg-gradient-gold px-3 py-2 text-xs font-bold text-white shadow-gold disabled:opacity-50 active:scale-95 transition-transform"
          title="स्टांप जोड़ें"
        >
          {stamping ? "⏳" : "+ स्टांप"}
        </button>
      </div>
    </div>
  );
}

function ManualToken({ onSubmit }: { onSubmit: (t: string) => void }) {
  const [v, setV] = useState("");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (v) { onSubmit(v); setV(""); } }} className="mt-2 flex gap-2">
      <input value={v} onChange={(e) => setV(e.target.value)} placeholder="ERQR-..." className="flex-1 rounded-xl border border-input bg-background px-3 py-2 font-mono text-xs focus:border-accent focus:outline-none" />
      <button className="rounded-xl bg-primary px-4 text-xs text-primary-foreground">Apply</button>
    </form>
  );
}

function Stat({ label, value, icon }: { label: string; value: string | number; icon: string }) {
  return (
    <div className="rounded-2xl bg-card p-4 shadow-card">
      <div className="flex items-center gap-2 mb-1">
        <span className="text-base">{icon}</span>
        <p className="text-[11px] uppercase tracking-wider text-text-light">{label}</p>
      </div>
      <p className="font-display text-2xl font-bold text-primary">{value}</p>
    </div>
  );
}

function Empty({ msg }: { msg: string }) {
  return <div className="rounded-2xl border-2 border-dashed border-border p-10 text-center text-sm text-text-light">{msg}</div>;
}
