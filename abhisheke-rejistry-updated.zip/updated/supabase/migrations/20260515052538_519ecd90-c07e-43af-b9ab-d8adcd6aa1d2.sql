ALTER TABLE public.owner_settings
  ADD COLUMN IF NOT EXISTS brand_name TEXT NOT NULL DEFAULT 'अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय',
  ADD COLUMN IF NOT EXISTS tagline TEXT NOT NULL DEFAULT 'हर रजिस्ट्री पर स्टांप, 5 स्टांप पर ₹2,000 इनाम',
  ADD COLUMN IF NOT EXISTS watermark TEXT NOT NULL DEFAULT 'Made by Abhishek Sharma from Agar',
  ADD COLUMN IF NOT EXISTS address TEXT NOT NULL DEFAULT 'आगर मालवा, मध्य प्रदेश',
  ADD COLUMN IF NOT EXISTS support_phone TEXT NOT NULL DEFAULT '';

UPDATE public.owner_settings
SET brand_name = 'अभिषेक कंप्यूटर एंड इ-रजिस्ट्री कार्यालय',
    tagline = 'हर रजिस्ट्री पर स्टांप, 5 स्टांप पर ₹2,000 इनाम',
    watermark = 'Made by Abhishek Sharma from Agar',
    address = 'आगर मालवा, मध्य प्रदेश'
WHERE brand_name IS NULL OR brand_name = '' OR brand_name = 'E-Registry';