
-- Customers table
CREATE TABLE public.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  name text NOT NULL,
  mobile text NOT NULL,
  aadhaar text,
  customer_code text NOT NULL UNIQUE,
  stamps int NOT NULL DEFAULT 0,
  rewards_claimed int NOT NULL DEFAULT 0,
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  UNIQUE(owner_id, mobile)
);

CREATE TABLE public.stamp_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  customer_id uuid NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  note text,
  type text NOT NULL CHECK (type IN ('stamp','reward')),
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE TABLE public.qr_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token text NOT NULL UNIQUE,
  customer_id uuid NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL,
  used boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);

CREATE TABLE public.owner_settings (
  owner_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  office_name text NOT NULL DEFAULT 'E-Registry Office',
  reward_amount int NOT NULL DEFAULT 2000,
  required_stamps int NOT NULL DEFAULT 5,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stamp_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.qr_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.owner_settings ENABLE ROW LEVEL SECURITY;

-- Customers: owner manages, public can read by code (for customer card login)
CREATE POLICY "owner_all_customers" ON public.customers FOR ALL TO authenticated
  USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "public_read_customers" ON public.customers FOR SELECT TO anon, authenticated
  USING (true);

-- Stamp history: owner manages, public read (for customer card view)
CREATE POLICY "owner_all_stamp_history" ON public.stamp_history FOR ALL TO authenticated
  USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "public_read_stamp_history" ON public.stamp_history FOR SELECT TO anon, authenticated
  USING (true);

-- QR tokens: public read + insert + update (so customer page can create tokens & scan page can mark used)
CREATE POLICY "public_all_qr_tokens" ON public.qr_tokens FOR ALL TO anon, authenticated
  USING (true) WITH CHECK (true);

-- Owner settings
CREATE POLICY "owner_settings_all" ON public.owner_settings FOR ALL TO authenticated
  USING (auth.uid() = owner_id) WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "public_read_owner_settings" ON public.owner_settings FOR SELECT TO anon, authenticated
  USING (true);

-- Auto-create owner_settings on signup
CREATE OR REPLACE FUNCTION public.handle_new_owner()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.owner_settings (owner_id) VALUES (NEW.id) ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_owner();

-- Apply stamp atomically
CREATE OR REPLACE FUNCTION public.apply_stamp_by_token(p_token text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_token public.qr_tokens%ROWTYPE;
  v_customer public.customers%ROWTYPE;
  v_settings public.owner_settings%ROWTYPE;
  v_new_stamps int;
  v_is_reward boolean := false;
BEGIN
  SELECT * INTO v_token FROM public.qr_tokens WHERE token = p_token;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'not_found'); END IF;
  IF v_token.used THEN RETURN jsonb_build_object('ok', false, 'error', 'already_used'); END IF;
  IF v_token.expires_at < now() THEN RETURN jsonb_build_object('ok', false, 'error', 'expired'); END IF;

  SELECT * INTO v_customer FROM public.customers WHERE id = v_token.customer_id;
  SELECT * INTO v_settings FROM public.owner_settings WHERE owner_id = v_customer.owner_id;
  IF v_settings.required_stamps IS NULL THEN
    v_settings.required_stamps := 5;
  END IF;

  IF v_customer.stamps > 0 AND v_customer.stamps % v_settings.required_stamps = 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'reward_pending', 'customer', row_to_json(v_customer));
  END IF;

  v_new_stamps := v_customer.stamps + 1;
  IF v_new_stamps % v_settings.required_stamps = 0 THEN v_is_reward := true; END IF;

  UPDATE public.customers SET stamps = v_new_stamps WHERE id = v_customer.id;
  UPDATE public.qr_tokens SET used = true WHERE id = v_token.id;
  INSERT INTO public.stamp_history (customer_id, type, note, owner_id)
    VALUES (v_customer.id, 'stamp', 'Registry #' || v_new_stamps || ' complete', v_customer.owner_id);

  v_customer.stamps := v_new_stamps;
  RETURN jsonb_build_object('ok', true, 'customer', row_to_json(v_customer), 'reward_ready', v_is_reward);
END;
$$;

GRANT EXECUTE ON FUNCTION public.apply_stamp_by_token(text) TO anon, authenticated;

-- Claim reward
CREATE OR REPLACE FUNCTION public.claim_reward(p_customer_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_customer public.customers%ROWTYPE;
  v_settings public.owner_settings%ROWTYPE;
BEGIN
  SELECT * INTO v_customer FROM public.customers WHERE id = p_customer_id AND owner_id = auth.uid();
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'error', 'not_found'); END IF;
  SELECT * INTO v_settings FROM public.owner_settings WHERE owner_id = v_customer.owner_id;
  IF v_settings.required_stamps IS NULL THEN v_settings.required_stamps := 5; END IF;
  IF v_customer.stamps = 0 OR v_customer.stamps % v_settings.required_stamps <> 0 THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_ready');
  END IF;
  UPDATE public.customers SET rewards_claimed = rewards_claimed + 1 WHERE id = v_customer.id;
  INSERT INTO public.stamp_history (customer_id, type, note, owner_id)
    VALUES (v_customer.id, 'reward', '₹' || v_settings.reward_amount || ' reward diya', v_customer.owner_id);
  RETURN jsonb_build_object('ok', true);
END;
$$;

GRANT EXECUTE ON FUNCTION public.claim_reward(uuid) TO authenticated;

-- Generate next customer code per owner
CREATE OR REPLACE FUNCTION public.next_customer_code(p_owner uuid)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_max int;
BEGIN
  SELECT COALESCE(MAX(CAST(SUBSTRING(customer_code FROM 'REG-(\d+)') AS int)), 0) INTO v_max
  FROM public.customers WHERE owner_id = p_owner;
  RETURN 'REG-' || LPAD((v_max + 1)::text, 4, '0');
END;
$$;

GRANT EXECUTE ON FUNCTION public.next_customer_code(uuid) TO authenticated;
