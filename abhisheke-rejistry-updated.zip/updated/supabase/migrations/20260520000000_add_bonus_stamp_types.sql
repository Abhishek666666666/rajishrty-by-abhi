-- Allow bonus and bonus_pending stamp types for Google Review feature
ALTER TABLE public.stamp_history
  DROP CONSTRAINT IF EXISTS stamp_history_type_check;

ALTER TABLE public.stamp_history
  ADD CONSTRAINT stamp_history_type_check
  CHECK (type IN ('stamp', 'reward', 'bonus', 'bonus_pending'));

-- Allow public (anon) to insert bonus_pending entries for Google Review
CREATE POLICY IF NOT EXISTS "public_insert_bonus_pending" ON public.stamp_history
  FOR INSERT TO anon
  WITH CHECK (type = 'bonus_pending');

-- Add brand_name and other settings columns if not exists
ALTER TABLE public.owner_settings
  ADD COLUMN IF NOT EXISTS brand_name text,
  ADD COLUMN IF NOT EXISTS tagline text,
  ADD COLUMN IF NOT EXISTS watermark text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS support_phone text;
